#include<reg51.h>
sbit SEG2=P3^0;
sbit SEG3=P3^1;
sbit SEG4=P3^2;
unsigned char seg[10] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
void delayxms(int x)
{
  int i;
	while(x--)
	  for(i=0;i<110;i++);
}
void display(float m)  //������Χ��0~99.9��
{
  unsigned int i;
	unsigned char shi,ge,fen;
	if((m>=100)||(m<0))
	{
	  SEG2=0;SEG3=0;SEG4=0;
		P2=0x76;
	}
	else
	{  
		i=m*10;				
		SEG2=0;SEG3=1;SEG4=1;
    shi=i/100;
		P2=seg[shi];						
		delayxms(1);
		SEG2=1;SEG3=1;SEG4=1;
		SEG2=1;SEG3=0;SEG4=1;
    ge=i%100/10;
		P2=seg[ge]|0x80;				
		delayxms(1);
		SEG2=1;SEG3=1;SEG4=1;
		SEG2=1;SEG3=1;SEG4=0;
		fen=i%10;
		P2=seg[fen];	
		delayxms(1);
    SEG2=1;SEG3=1;SEG4=1;		
	}	
}
void main()
{
  display(56.9);//������Χ��0~99.9��
}
