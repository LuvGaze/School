#include<reg51.h>
sbit button = P2^0;
unsigned char led=0x08;
void delay1s()
{
  int i,j;
	for(i=0;i<1000;i++)
	  for(j=0;j<110;j++);
}
void main()
{
	while(2)
	{
	  if(button)
	  {
	    if(led==0x80)
				led=0x01;
			else
				led<<=1;
	  }
		else
		{
		  if(led==0x01)
				led=0x80;
			else
				led>>=1;
		}
		P3=led;
		delay1s();
	}
}