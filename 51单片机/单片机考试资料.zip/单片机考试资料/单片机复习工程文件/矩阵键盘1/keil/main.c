#include<reg51.h>
unsigned char code SEG[]= {0x06,0x5b,0x4f,0x66,0x6d,0x7d}; //����������Ϊ�ַ�1~6�Ĺ�������
void delay1ms(unsigned int x)
{
  unsigned char i;
  while(x--)
  for(i=0;i<110;i++);
}
unsigned char keyscan()
{
  unsigned char row,col=0xff,k=0xff,temp;
  P2=0xf0;	    
  if(P2==0xf0)	
    return k;	
  delay1ms(20);	
  if(P2==0xf0)	
    return k;
  for(row=0;row<=3;row++)	
  {
    if(row==0) P2=0xfe;		
		if(row==1) P2=0xfd;		
		if(row==2) P2=0xfb;		
		if(row==3) P2=0xf7;		
		temp=P2&0xf0;			
		if(temp==0xe0)			
		{col=0;break;}			
		if(temp==0xd0)			
		{col=1;break;}			
		if(temp==0xb0)			
		{col=2;break;}			
		if(temp==0x70)			
		{col=3;break;}			
  }
  if(col==0xff)				
      return k;				
  else
	  k=row*4+col;			
  return k;  
}
void main()
{
  unsigned char key;
	P1=0x00; //��ʼ״̬����ܲ���
  while(1)
  {
    key=keyscan();
    switch(key)		
		{
		  case 0:P1=SEG[key];break;
			case 1:P1=SEG[1];break;
			case 2:P1=SEG[key];break;
			case 4:P1=SEG[key-1];break;
			case 5:P1=SEG[4];break;
			case 6:P1=SEG[5];break;
			default:break;
		}
  }
}