#include<reg51.h>		 

unsigned char smg[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d, 0x07,0x7f,0x6f};

sbit P2_2 = P2^2;

void Delay(unsigned int x)		//	延迟函数
{
  unsigned char i,j;
  for(i=0;i<x;i++)
    for(j=0;j<=110;j++);
}

void Uart_Init()
{
	SCON = 0x50;				//	设置串口工作在方式1，8位UART模式，允许接收
    TMOD &= 0x0;				//	清除TMOD寄存器低4位，准备设置波特率
    TMOD |= 0x20;				//	设置定时器1工作在模式2，用于波特率发生
    TH1 = 0xFD;					//	根据晶振频率设置波特率的TH1初值
    TL1 = 0xFD;
    TR1 = 1;					//	启动定时器1
    ES = 1;						//	允许串口中断
    EA = 1;						//	允许总中断
}

unsigned char Key()				//	获取按键
{
  if(P2_2==0)
  {
    Delay(20);
    while(P2_2==0)
	Delay(20);
	return 1;					//	按下返回1
  }
  return 0;						//	未按下返回0
}

void main()
{
  unsigned char key=0,t=0;
  Uart_Init();
  P0=0;
  while(1)
  {		
    key=Key();					//	接收按键
    if(key!=0)
    {
		SBUF=t;					//	发送数据
		while(!TI);
		TI=0;
		t++;					//	数值每次加1
		if(t==10)t=0;
    }
    Delay(10);
  }
}

void Uart_Int() interrupt 4     
{
  unsigned char t;
  if(RI==1)						//	接收数据  
  { 
    RI=0; 
    t=SBUF;  
    P0=smg[t];					//	显示数码管
  }
}