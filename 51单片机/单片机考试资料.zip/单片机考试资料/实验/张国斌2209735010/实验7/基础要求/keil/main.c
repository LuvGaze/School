#include <reg51.H>

void main()
{	
	SCON = 0x50;								//	设置串口工作在方式1，8位UART模式，允许接收
    TMOD = 0x20;								//	设置定时器1工作在模式2，用于波特率发生
    TH1 = 0xFD;									//	根据晶振频率设置波特率的TH1初值
    TL1 = 0xFD;
    TR1 = 1;									//	启动定时器1
    ES = 1;										//	允许串口中断
    EA = 1;										//	允许总中断
	
	while(1);									//	空循环等待中断处理}
}

void Inter() interrupt 4
{	
	unsigned char date;
	if(TI==1)									//	等待发送完成
		TI = 0; 								//	清除发送中断标志}
	else  
	{    
		RI   = 0; 								//	清接收中断标志
		date = SBUF;							//	读取接收缓冲数据
		if(date>='a'&&date<='z')SBUF = date-32;	//	判断，发送更改后的数据
	}
}