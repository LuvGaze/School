#include <reg51.h>

sbit P2_0=P2^0;
sbit P2_1=P2^1;
sbit P2_2=P2^2;
sbit P2_3=P2^3;
sbit P2_4=P2^4;
sbit P2_5=P2^5;
sbit P2_6=P2^6;
sbit P2_7=P2^7;

int shi=23,fen=58,miao=50;														//	初始时间

unsigned char smg[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x40};


void Delay(unsigned int xms)													//	延时函数
{
	unsigned char i;
	while(xms--)
	{
		for(i=0;i<110;i++);
	}
}

void Nixie(unsigned int Location,Number)										//	数码管显示函数，用于显示数字
{
	switch(Location)															//	选择数码管
	{
		case 1:P2_0=0;P2_1=1;P2_2=1;P2_3=1;P2_4=1;P2_5=1;P2_6=1;P2_7=1;break;
		case 2:P2_0=1;P2_1=0;P2_2=1;P2_3=1;P2_4=1;P2_5=1;P2_6=1;P2_7=1;break;
		case 3:P2_0=1;P2_1=1;P2_2=0;P2_3=1;P2_4=1;P2_5=1;P2_6=1;P2_7=1;break;
		case 4:P2_0=1;P2_1=1;P2_2=1;P2_3=0;P2_4=1;P2_5=1;P2_6=1;P2_7=1;break;
		case 5:P2_0=1;P2_1=1;P2_2=1;P2_3=1;P2_4=0;P2_5=1;P2_6=1;P2_7=1;break;
		case 6:P2_0=1;P2_1=1;P2_2=1;P2_3=1;P2_4=1;P2_5=0;P2_6=1;P2_7=1;break;
		case 7:P2_0=1;P2_1=1;P2_2=1;P2_3=1;P2_4=1;P2_5=1;P2_6=0;P2_7=1;break;
		case 8:P2_0=1;P2_1=1;P2_2=1;P2_3=1;P2_4=1;P2_5=1;P2_6=1;P2_7=0;break;
	}
	P0=smg[Number];																//	数码管显示数字
	Delay(1);
	P2_0=1;P2_1=1;P2_2=1;P2_3=1;P2_4=1;P2_5=1;P2_6=1;P2_7=1;
}


void Time()																		//	时间显示
{
	Nixie(1,shi/10);
	Nixie(2,shi%10);
	Nixie(3,10);
	Nixie(4,fen/10);
	Nixie(5,fen%10);
	Nixie(6,10);
	Nixie(7,miao/10);
	Nixie(8,miao%10);
}

void Time_Init()																//	时间变换
{
	if(miao>=60){miao=0;fen++;}
	if(miao<0){miao=59;fen--;}
	if(fen>=60){fen=0;shi++;}
	if(fen<0){fen=59;shi--;}
	if(shi>=24){shi=0;}
	if(shi<0){shi=23;}
}

void Timer0_Init()																//	定时器初始化
{
	TMOD |= 0x01;
	TL0 = 0x18;
	TH0 = 0xFC;
	TF0 = 0;
	TR0 = 1;
	ET0=1;
	EA=1;
	PT0=0;
}

void main()
{
	Timer0_Init();																//	定时器初始化
	while(1)
	{
		Time();																	//	显示时间
	}
}

unsigned int count=0;
void Timer0() interrupt 1														// 定时器0中断服务函数
{
	TL0 = 0x67;
	TH0 = 0xFC;
	count++;
	if(count>1000)				
	{
		count = 0;
		miao++;
		Time_Init();
	}
}