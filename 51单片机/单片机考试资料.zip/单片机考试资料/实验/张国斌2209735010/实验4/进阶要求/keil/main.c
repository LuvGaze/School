#include <reg51.h>

void Delay(unsigned int x){
	unsigned int i,j;
	for(i=0;i<x;i++)
		for(j=0;j<110;j++);
}

void main(void){
    IT0 = 1;															//	INT0下降沿触发
    IT1 = 1; 															//	INT1下降沿触发
    EX0 = 1;															//	允许INT0中断
    EX1 = 1;															//	允许INT1中断
    PX1 = 1;															//	设置INT1为高优先级中断
    EA = 1;																//	开启总中断
    while(1){
		P2 = 0xff;}}

void Inter1() interrupt 0 using 1{										//	普通中断
    P2=0x00;Delay(2000);P2=0xff;Delay(2000);P2=0x00;Delay(2000);P2=0xff;
    IE0 = 0;
}

void Inter2() interrupt 2 using 2										//	优先中断
{
	unsigned char i;
    for(i=0;i<2;i++){													//	P2状态改变
        P2=0xaa;
        Delay(2000);
		P2=0x00;
		Delay(2000);}
    EX0 = 1;
    IE1 = 0;
}