#include <reg51.h>

void Delay(unsigned int x){				//	延时函数
	unsigned int i, j;
	for(i=0;i<x;i++)
		for(j=0;j<110;j++);
}

void main(){
	IT0=1;								//	设置外部中断0为边沿触发，IT0=1表示下降沿触发
	EX0=1;								//	允许外部中断0
	EA=1;								//	开启全局中断允许
	PX0=0;								//	设置外部中断0为低优先级

	while(1){
		P2=0xff;						//	默认点亮所有LED
	}
}

void Int0() interrupt 0{				//	INT0中断服务程序
	unsigned int i = 0;
    for(i=0;i<20;i++){					//	循环两次，实现两次状态翻转
		P2=0x00;							//	P2口状态翻转
		Delay(1000);					//	延时2秒
		P2=0xff;							//	再次翻转状态
		Delay(1000);					//	再次延时2秒
    }
    IE0 = 0;							//	禁用了外部中断0
}