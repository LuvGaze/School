#include <reg51.h>

sbit P1_0 = P1^0;

unsigned int count = 0;									//	计时器计数变量
unsigned int moshi = 0;									//	LED显示模式控制变量
unsigned int a = 0, b = 0;								//	LED闪烁位置控制变量

void Timer0_Init(){										//	初始化定时器0
	TMOD &= 0xF0;
	TMOD |= 0x01;
	TL0 = 0x66;
	TH0 = 0xFC;
	TF0 = 0;
	TR0 = 1;
	ET0=1;
	EA=1;
	PT0=0;
}

void Delay(unsigned int x){
	unsigned char i;
	while(x--)
	{
		for(i=0;i<110;i++);
	}
}

void LED(){
	switch(moshi){										//	根据模式变量moshi选择不同的闪烁方式
		case 0:P2=0x80>>a;a++;if(a>=8)a=0;b=8-a;break;	//	模式0：从左到右依次点亮
		case 1:P2=0x01<<b;b++;if(b>=8)b=0;a=8-b;break;	//	模式1：从右到左依次点亮
	}
}

void main(){
	Timer0_Init();										//	调用初始化定时器0的函数
	P2=0x00;											//	初始化P2口为0，关闭所有LED
	while(1){	
		if(P1_0==0){									//	检测P1_0是否被按下
			Delay(20);									//	延时消抖
			while(P1_0==0){moshi=1;}					//	改变模式为1
			Delay(20);
			count=1000;									//	重置计数器
		}
		else moshi = 0;									//	若P1_0未按下，恢复模式0
		if(P2==0x00){									//	当P2口输出全为0时
			LED();										//	调用LED函数更新LED显示
		}
	}
}

void Timer0() interrupt 1{
	TL0 = 0x66;											//	重装载定时器0初值
	TH0 = 0xFC;
	count++;											//	计数器加1
	if(count>922){
		LED();											//	调用LED函数更新LED状态
		count = 0;										//	重置计数器
	}
}