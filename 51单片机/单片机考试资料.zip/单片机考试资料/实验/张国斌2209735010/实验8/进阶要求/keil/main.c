#include <reg51.h>

sbit SCK = P2^5;
sbit CS  = P2^6;
sbit DIN = P2^7;

unsigned int count = 0, i = 0;
unsigned int t = 10;				//	t = 1s(1000ms) / 频率100

void Timer0_Init()					//	初始化Timer0用于产生定时间隔的中断
{
	TMOD |= 0x01;					//	配置TMOD寄存器，设置模式为模式1（16位定时器）
    TH0 = 0xFC;						//	重载值设置，配合TL0设置产生特定时间间隔的中断
    TL0 = 0x18;       
    EA = 1;							//	开启全局中断允许
    ET0 = 1;						//	开启Timer0中断
    TR0 = 1;						//	启动Timer0
}

void TLC5615_DAC(unsigned int adata)//	D/A转换函数，将数字量转换为模拟电压输出至TLC5615
{
	unsigned int i;
	adata <<= 6;					//	数据左移6位，与TLC5615的12位分辨率对齐
	SCK = 0;						//	串行时钟低电平开始
	CS  = 0;						//	片选有效，开始数据传输
	for(i=0; i<12; i++)				//	循环发送12位数据
	{
		SCK = 0;					//	时钟信号下降沿准备
		adata <<= 1;				//	数据左移一位，最低位补0
		DIN = adata & 0x8000;		//	取数据的最高位送入DIN
		SCK = 1;					//	时钟信号上升沿，D/A芯片读取数据
	}
	CS  = 1;						//	数据传输完毕，取消片选
	SCK = 0;						//	时钟信号回到低电平状态
}

void main()
{
	Timer0_Init();					//	初始化Timer0
	while(1);
}

void Timer0() interrupt 1
{
	TH0 = 0xFC;						//	重装载计数器，保持定时周期不变
	TL0 = 0x18;
	count++;						//	计数器加一

	if(count <= t)					//	在指定计数周期内生成上升沿波形
	{
		i=(count*224 / t);			//	线性增加i的值，以产生上升斜率，112为满幅度的近似值
	}
	else
	{
		count=0;					//	达到t后重置计数，准备下降沿
	}
	TLC5615_DAC(i);					//	调用D/A转换函数输出当前计算的模拟电压值
}