#include<reg51.h>

unsigned char Seg[10]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};

void Delay(unsigned int xms)
{
	unsigned char i, j;
	while(xms--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
	}
}

unsigned char Keyscan()
{
	unsigned KeyNum;
	P2=0xff;
	if(P2!=0xff)
	{
		Delay(20);
	}
	switch(P2)
	{
		case 0xfe: KeyNum = 0;   break;
		case 0xfd: KeyNum = 1;   break;
		case 0xfb: KeyNum = 2;   break;
		case 0xf7: KeyNum = 3;   break;
		case 0xef: KeyNum = 4;   break;
		case 0xdf: KeyNum = 5;   break;
		case 0xbf: KeyNum = 6;   break;
		case 0x7f: KeyNum = 7;   break;
		default:   KeyNum = 100; break;
	}
	return KeyNum;
}

void main()
{
	unsigned Key;
	while(1)
	{
		Key = Keyscan();
		if(Key!=100)
		{
			P1 = Seg[Key];
		}
	}
}