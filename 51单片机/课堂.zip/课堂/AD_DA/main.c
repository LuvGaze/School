#include <reg51.h>

sbit SCK = P2^5;
sbit CS  = P2^6;
sbit DIN = P2^7;

void TLC5615DAC(unsigned int adata)
{
	unsigned int i;
	adata <<= 6;
	SCK	= 0;
	CS  = 0;
	for(i=0;i<12;i++)
	{
		SCK = 0;
		adata <<= 1;
		DIN = CY;
		SCK = 1;
	}
	CS  = 1;
	SCK = 0;
}

void main()
{
	unsigned int i;
	while(1)
	{
		for(i=0;i<1000;i++)
		{
			TLC5615DAC(i);
		}
	}
}