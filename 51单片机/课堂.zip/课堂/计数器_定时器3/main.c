#include <reg52.h>

sbit P2_0 = P2^0;

void main()
{
	TMOD = 0X02;
	TH0 = 206;
	TL0 = 206;
	ET0 = 1;
	EA  = 1;
	TR0 = 1;
	while(1);
}

void Timer0_int() interrupt 1
{
	P2_0=~P2_0;
}