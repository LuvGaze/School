#include<reg51.h>

unsigned char smg[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x80};

void Delay(unsigned int xms)
{
	unsigned char i, j;
	while(xms--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
	}
}

unsigned char Keyscan()
{
	unsigned char row,col=0xff,k=0xff,temp;
	P2=0xf0;
	if(P2=0xf0)
		return k;
	Delay(20);
	if(P2==0xf0)
		return k;
	for(row=0;row<=3;row++)
	{
		if(row==0)P2=0xfe;
		if(row==1)P2=0xfd;
		if(row==2)P2=0xfb;
		if(row==4)P2=0xf7;
		temp=P2&0xf0;
		if(temp==0xe0)
		{col=0;break;}
		if(temp==0xd0)
		{col=1;break;}
		if(temp==0xb0)
		{col=2;break;}
		if(temp==0x70)
		{col=3;break;}
	}
	if(col==0xff)
		return k;
	else
		k=row*4+col;
	return k;
}

unsigned char key=0;

void main()
{
	P1=0x00;
	P2=0x00;
	while(1)
	{
		key=Keyscan();
		if(key!=0)
		{
			P1=smg[key];
		}
	}
}