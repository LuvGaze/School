#include <regx52.h>

sbit

void Delay(unsigned int x)
{
	unsigned int i;
	while(--x)
	{
		for(i=110;i>0;i--);
	}
}

