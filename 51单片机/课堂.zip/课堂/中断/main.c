#include <reg51.h>

void Delay(unsigned int xms)
{
	unsigned char i, j;
	while(xms--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
	}
}

unsigned char a,b;

void main()
{
	IT0=1;
	IT1=1;
	EX0=1;
	EX1=1;
	EA=1;
	
	PX0=0;
	PX1=1;
	
	a=0;
	while(1)
	{
		if(a>=8)a=0;
		P1=0x01<<a;Delay(200);
		a++;
	}
}

void Int0() interrupt 0
{
	A=0;
	while(1)
	{
		if(b>=8)a=0;
		P1=0x01<<b;Delay(200);
		b+=2;
	}
}

void Int1() interrupt 1
{
	a=0;
	while(1)
	{
		if(a>=8)a=0;
		P1=0x01<<a;Delay(200);
		a++;
	}
}