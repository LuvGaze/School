#include <reg51.h>
sbit a1=P3^0;
sbit a2=P3^1;
sbit a3=P3^2;
sbit a4=P3^3;
sbit a5=P3^4;
sbit a6=P3^5;
sbit a7=P3^6;
sbit a8=P3^7;

unsigned char smg[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x80};

void Delay(unsigned int xms)
{
	unsigned char i, j;
	while(xms--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
	}
}

void Nixie(unsigned int Location,Number)
{
	switch(Location)
	{
		case 1:a1=0;a2=1;a3=1;a4=1;a5=1;a6=1;a7=1;a8=1;break;
		case 2:a1=1;a2=0;a3=1;a4=1;a5=1;a6=1;a7=1;a8=1;break;
		case 3:a1=1;a2=1;a3=0;a4=1;a5=1;a6=1;a7=1;a8=1;break;
		case 4:a1=1;a2=1;a3=1;a4=0;a5=1;a6=1;a7=1;a8=1;break;
		case 5:a1=1;a2=1;a3=1;a4=1;a5=0;a6=1;a7=1;a8=1;break;
		case 6:a1=1;a2=1;a3=1;a4=1;a5=1;a6=0;a7=1;a8=1;break;
		case 7:a1=1;a2=1;a3=1;a4=1;a5=1;a6=1;a7=0;a8=1;break;
		case 8:a1=1;a2=1;a3=1;a4=1;a5=1;a6=1;a7=1;a8=0;break;
	}
	P2=smg[Number];
	Delay(1);
	a1=1;a2=1;a3=1;a4=1;a5=1;a6=1;a7=1;a8=1;
}

unsigned int nian=2024,yue=3,ri=21;

void main()
{
	while(1)
	{
		Nixie(1,nian/1000);
		Nixie(2,nian%1000/100);
		Nixie(3,nian%100/10);
		Nixie(4,nian%10);Nixie(4,10);
		Nixie(5,yue/10);
		Nixie(6,yue%10);Nixie(6,10);
		Nixie(7,ri/10);
		Nixie(8,ri%10);
;	}
}