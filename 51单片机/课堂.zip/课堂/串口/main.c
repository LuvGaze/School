#include <reg51.h>
#include <string.h>

unsigned char i=0,j=0,len;
unsigned char array[] = "abc",Text[];

void main()
{
	SCON = 0X40;
	TMOD = 0X20;
	TH1  = 253;
	TL1  = 253;
	TR1  = 1;
	ES   = 1;
	EA   = 1;
	
	len = strlen(array);
	for(j=0;j<len;j++)
	{
		Text[j] = array[j]-32;
	}
	SBUF = Text[i];
	while(1);
}

void Send() interrupt 4
{
	TI   = 0;
	SBUF = Text[++i];
	if(i==len)ES = 0;
}