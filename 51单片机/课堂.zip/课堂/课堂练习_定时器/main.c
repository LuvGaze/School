#include <regx52.h>

int shi=23,fen=58,miao=50;						//	初始时间

unsigned char Nixie[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};


void Delay(unsigned int xms)
{
	unsigned char i, j;
	while(xms--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
	}
}

void Time()										//	时间显示
{
	P2_4=1;P2_3=1;P2_2=1;P0=Nixie[shi/10];Delay(1);P0=0x00;
	P2_4=1;P2_3=1;P2_2=0;P0=Nixie[shi%10];Delay(1);P0=0x00;
	
	P2_4=1;P2_3=0;P2_2=0;P0=Nixie[fen/10];Delay(1);P0=0x00;
	P2_4=0;P2_3=1;P2_2=1;P0=Nixie[fen%10];Delay(1);P0=0x00;
	
	P2_4=0;P2_3=0;P2_2=1;P0=Nixie[miao/10];Delay(1);P0=0x00;
	P2_4=0;P2_3=0;P2_2=0;P0=Nixie[miao%10];Delay(1);P0=0x00;
	
	P2_4=1;P2_3=0;P2_2=1;P0=0x40;Delay(1);P0=0x00;
	P2_4=0;P2_3=1;P2_2=0;P0=0x40;Delay(1);P0=0x00;
}

void Time_Init()								//	时间变换
{
	if(miao>=60){miao=0;fen++;}
	if(miao<0){miao=59;fen--;}
	if(fen>=60){fen=0;shi++;}
	if(fen<0){fen=59;shi--;}
	if(shi>=24){shi=0;}
	if(shi<0){shi=23;}
}

void Timer0_Init()
{
	TMOD &= 0xF0;		//设置定时器模式
	TMOD |= 0x02;		//设置定时器模式
	TL0 = 0x18;			//设置定时初值
	TH0 = 0xFC;			//设置定时初值
	TF0 = 0;			//清除TF0标志
	TR0 = 1;			//定时器0开始计时
	ET0=1;
	EA=1;
	PT0=0;
}

void main()
{
	Timer0_Init();
	while(1)
	{
		Time();
	}
}

unsigned int count=0;
void Timer0() interrupt 1
{
	TL0 = 0x66;
	TH0 = 0xFC;
	
	count++;
	if(count>922)				
	{
		count = 0;
		miao++;
		Time_Init();
	}
}