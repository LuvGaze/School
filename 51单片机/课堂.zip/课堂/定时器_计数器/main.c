#include<reg51.h>
unsigned char code SEG[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
sbit seg1 = P3^0;
sbit seg2 = P3^1;
sbit seg3 = P3^2;
sbit seg4 = P3^3;
sbit seg5 = P3^6;
sbit seg6 = P3^7;
void delaylms(unsigned int x)
{
	unsigned char i;
	while(x--)
		for(i=0;i<123;i++);
}
void display6seg(unsigned int x)
{
	unsigned char temp;
	seg1 = 1;seg2 = 1;
	seg3 = 1;seg4 = 1;
	seg5 = 1;seg6 = 1;
	seg1 = 1;
	P2=SEG[0];//
	delaylms(5);
	seg1 = 1;
	seg2 = 0;
	temp=x/10000;
	P2=SEG[temp];
	delaylms(5);
	seg2 = 1;
	seg3 = 0;
	temp=(x%10000)/1000;
	P2=SEG[temp];
	delaylms(5);
	seg3 = 1;
	seg4 = 0;
	temp=(x%1000)/100;
	P2=SEG[temp];
	delaylms(5);
	seg4 = 1;
	seg5 = 0;
	temp=(x%100)/10;
	P2=SEG[temp];
	delaylms(5);
	seg5 = 1;
	seg6 = 0;
	temp=x%10;
	P2=SEG[temp];
	delaylms(5);
	seg6=1;
}
void main()
{
	unsigned int count;
	TMOD=0x05;
	TH0=0;TL0=0;
	TR0=1;
	while(1)
	{
		count =TH0*256+TL0;
		display6seg(count);
	}
}