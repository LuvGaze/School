#include<reg52.h>

unsigned char code SEG[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
sbit seg1 = P3^0;
sbit seg2 = P3^1;
sbit seg3 = P3^2;
sbit seg4 = P3^3;
sbit seg5 = P3^6;
sbit seg6 = P3^7;

void Delay(unsigned int xms)
{
	unsigned char i, j;
	while(xms--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
	}
}

void display6seg(unsigned int x)
{
	unsigned char temp;
	seg1 = 1;seg2 = 1;
	seg3 = 1;seg4 = 1;
	seg5 = 1;seg6 = 1;
	seg1 = 1;
	P2=SEG[0];//
	Delay(5);
	seg1 = 1;
	seg2 = 0;
	temp=x/10000;
	P2=SEG[temp];
	Delay(5);
	seg2 = 1;
	seg3 = 0;
	temp=(x%10000)/1000;
	P2=SEG[temp];
	Delay(5);
	seg3 = 1;
	seg4 = 0;
	temp=(x%1000)/100;
	P2=SEG[temp];
	Delay(5);
	seg4 = 1;
	seg5 = 0;
	temp=(x%100)/10;
	P2=SEG[temp];
	Delay(5);
	seg5 = 1;
	seg6 = 0;
	temp=x%10;
	P2=SEG[temp];
	Delay(5);
	seg6=1;
}

unsigned int count,chushi;

void main()
{
	TMOD = 0X05;
	chushi = 65535-10;
	TH0 = chushi/256;
	TL0 = chushi%256;
	TR0 = 1;
	ET0 = 1;
	EA  = 1;
	while(1)
	{
		count = TH0*256 + TL0 - chushi;
		display6seg(count);
	}
}

void int_T0() interrupt 1
{
	TH0 = chushi/256;
	TL0 = chushi%256;
}