#include <reg51.h>

/*
unsigned char i;
unsigned int j;

void Delay()
{
	for(i=100;i>0;i--)
		for(j=100;j>0;j--);
}

void main()
{
	P3_2 = 0;
	SCON = 0x00;
	SBUF = P2;
	while(1)
	{
		if(TI)
		{
			TI = 0;
			P3_2 = 1;
			Delay();
			SBUF = P2;
		}
	}
}
*/

unsigned char i = 0;
unsigned char array[] = "Hello,World!";

void main()
{
	SCON = 0X50;
	TMOD = 0X20;
	TH1  = 253;
	TL1  = 253;
	TR1  = 1;
	ES   = 1;
	EA   = 1;
	while(1);
}

void Send() interrupt 4
{
	if(TI)
	{
		TI=0;
	}
	else 
	{
		RI   = 0;
		ACC  = SBUF;
		SBUF = ACC  + 1;
	}
}