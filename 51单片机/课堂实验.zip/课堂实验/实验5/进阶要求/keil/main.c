#include <reg51.h>

sbit P3_0 = P3^0;
sbit P3_1 = P3^1;
sbit P3_2 = P3^2;

unsigned int a = 0;
unsigned char Nixie[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};

void Delay(unsigned int x)				//	延迟函数
{
	unsigned int i,j;
	for(i=0;i<x;i++)
		for(j=0;j<110;j++);
}

void SMG(unsigned int Location,Number)	//	显示函数，负责在指定位置显示数字
{
	switch(Location)					//	选择数码管
	{
		case 1:P3_0=0;P3_1=1;break;
		case 2:P3_0=1;P3_1=0;break;
	}
	P2=Nixie[Number];Delay(1);			//	数码管显示数字
	P3_0=1;P3_1=1;
}

void Timer0_Init()
{
	TMOD &= 0xF0;						//设置定时器模式
	TMOD |= 0x01;						//设置定时器模式
	TL0 = 0x66;							//设置定时初值
	TH0 = 0xFC;							//设置定时初值
	TF0 = 0;							//清除TF0标志
	TR0 = 1;							//定时器0开始计时
	ET0=1;
	EA=1;
	PT0=0;
}

void main()
{
	Timer0_Init();
	while(1)
	{
		SMG(1,a/10);					//	显示十位
		SMG(2,a%10);					//	显示个位
		if(P3_2==0)						//	按键检测
		{
			Delay(20);
			while(P3_2==0);
			Delay(20);
			a++;						//	计数加1
		}	
		if(a==20)a=0;					//	判断计数是否需要置0
	}
}

void Timer0() interrupt 1
{
	TL0 = 0x66;							//	重装载初值
	TH0 = 0xFC;
}