#include <reg51.h>

sbit P3_0 = P3^0;
sbit P3_1 = P3^1;
sbit P3_2 = P3^2;

unsigned int a = 0;
unsigned char Nixie[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};

void Delay(unsigned int x){													//	自定义延时函数
	unsigned int i,j;
	for(i=0;i<x;i++)
		for(j=0;j<110;j++);
}

void SMG(unsigned int Location,Number){										//	显示函数，用于在指定位置显示指定数字
	switch(Location){														//	输出对应数字的段码到P2口，用于显示
		case 1:P3_0=0;P3_1=1;break;
		case 2:P3_0=1;P3_1=0;break;
	}
	P2=Nixie[Number];Delay(1);												//	输出对应数字的段码到P2口，用于显示
	P3_0=1;P3_1=1;
}

void main()
{
	while(1){
		SMG(1,a/10);														//	显示十位数字
		SMG(2,a%10);														//	显示个位数字
		if(P3_2==0){														//	按键检测
			Delay(20);while(P3_2==0);Delay(20);
			a++;															//	计数器加一
		}
	}
}