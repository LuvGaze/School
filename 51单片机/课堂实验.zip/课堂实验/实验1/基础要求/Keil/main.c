#include <reg51.h>

sbit P1_0 = P1^0;
sbit P1_1 = P1^1;

void Delay(){					//	延时函数
	unsigned char i=110;
	while (--i);
}

void LED(unsigned int x){
	switch(x){
		case 1:P2=0xf0;break;	//	左边4个LED灯亮
		case 2:P2=0x55;break;	//	8个LED灯间隔亮
	}
}

void main(){
	unsigned int moshi=0;
	P2=0xff;					//	LED初始化
	while(1){
		if(P1_0==0){			//	按键1
			Delay();
			while(P1_0==0);
			Delay();
			moshi=1;
		}
		if(P1_1==0){			//	按键2
			Delay();
			while(P1_1==0);
			Delay();
			moshi=2;
		}
		LED(moshi);				//	刷新LED状态
	}
}