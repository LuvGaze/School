/*


		  1		2	  3		NULL
		
		
		  4		5	  6		NULL
		  
		
		  7		8	  9		NULL
		
		
		NULL	0	NULL	NULL


*/

#include <reg51.h>

sbit P2_0 = P2^0;
sbit P2_1 = P2^1;
sbit P2_2 = P2^2;
sbit P2_3 = P2^3;
sbit P2_4 = P2^4;
sbit P2_5 = P2^5;
sbit P2_6 = P2^6;
sbit P2_7 = P2^7;

unsigned char smg[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};

void Delay(unsigned int x){										//	延时函数
	unsigned char i,j;
	for(i=0;i<x;i++)for(j=0;j<110;j++);
}

unsigned char MatrixKey(){										//	矩阵键盘扫描函数，返回当前按下的键值
	unsigned int KeyNumber;
	P2=0xFF;P2_3=0;
	if(P2_5==0){Delay(20);while(P2_5==0);Delay(20);KeyNumber=0;}
	P2=0xFF;P2_2=0;
	if(P2_6==0){Delay(20);while(P2_6==0);Delay(20);KeyNumber=9;}
	if(P2_5==0){Delay(20);while(P2_5==0);Delay(20);KeyNumber=8;}
	if(P2_4==0){Delay(20);while(P2_4==0);Delay(20);KeyNumber=7;}
	P2=0xFF;P2_1=0;
	if(P2_6==0){Delay(20);while(P2_6==0);Delay(20);KeyNumber=6;}
	if(P2_5==0){Delay(20);while(P2_5==0);Delay(20);KeyNumber=5;}
	if(P2_4==0){Delay(20);while(P2_4==0);Delay(20);KeyNumber=4;}
	P2=0xFF;P2_0=0;
	if(P2_6==0){Delay(20);while(P2_6==0);Delay(20);KeyNumber=3;}
	if(P2_5==0){Delay(20);while(P2_5==0);Delay(20);KeyNumber=2;}
	if(P2_4==0){Delay(20);while(P2_4==0);Delay(20);KeyNumber=1;}
	return KeyNumber;											//	返回检测到的键值
}

unsigned char key;

void main(){
	P1=0x00;P2=0x00;											//	初始化P1，P2
	while(1){
		key=MatrixKey();										//	将键值转换为对应的七段码显示在数码管上
		P1=smg[key];											//	将键值转换为对应的七段码显示在数码管上
	}
}