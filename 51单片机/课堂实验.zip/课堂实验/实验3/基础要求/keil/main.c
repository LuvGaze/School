/*


		0	1	2	3
		
		4	5	6	7
		
		8	9	A	B
		
		C	D	E	F


*/

#include <reg51.h>

sbit P2_0 = P2^0;
sbit P2_1 = P2^1;
sbit P2_2 = P2^2;
sbit P2_3 = P2^3;
sbit P2_4 = P2^4;
sbit P2_5 = P2^5;
sbit P2_6 = P2^6;
sbit P2_7 = P2^7;

unsigned char smg[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};

void Delay(unsigned int xms){											//	延时函数，参数xms代表需要延迟的毫秒数
	unsigned char i, j;
	for(i=0;i<x;i++)for(j=0;j<110;j++);
}

unsigned char MatrixKey(){												//	矩阵键盘扫描函数，返回按键对应的键值
	unsigned int KeyNumber;
	P2=0xFF;P2_3=0;
	if(P2_7==0){Delay(20);while(P2_7==0);Delay(20);KeyNumber=15;}
	if(P2_6==0){Delay(20);while(P2_6==0);Delay(20);KeyNumber=14;}
	if(P2_5==0){Delay(20);while(P2_5==0);Delay(20);KeyNumber=13;}
	if(P2_4==0){Delay(20);while(P2_4==0);Delay(20);KeyNumber=12;}
	P2=0xFF;P2_2=0;
	if(P2_7==0){Delay(20);while(P2_7==0);Delay(20);KeyNumber=11;}
	if(P2_6==0){Delay(20);while(P2_6==0);Delay(20);KeyNumber=10;}
	if(P2_5==0){Delay(20);while(P2_5==0);Delay(20);KeyNumber=9;}
	if(P2_4==0){Delay(20);while(P2_4==0);Delay(20);KeyNumber=8;}
	P2=0xFF;P2_1=0;
	if(P2_7==0){Delay(20);while(P2_7==0);Delay(20);KeyNumber=7;}
	if(P2_6==0){Delay(20);while(P2_6==0);Delay(20);KeyNumber=6;}
	if(P2_5==0){Delay(20);while(P2_5==0);Delay(20);KeyNumber=5;}
	if(P2_4==0){Delay(20);while(P2_4==0);Delay(20);KeyNumber=4;
	P2=0xFF;P2_0=0;
	if(P2_7==0){Delay(20);while(P2_7==0);Delay(20);KeyNumber=3;}
	if(P2_6==0){Delay(20);while(P2_6==0);Delay(20);KeyNumber=2;}
	if(P2_5==0){Delay(20);while(P2_5==0);Delay(20);KeyNumber=1;}
	if(P2_4==0){Delay(20);while(P2_4==0);Delay(20);KeyNumber=0;}
	return KeyNumber;													//	返回检测到的键值
}

unsigned char key;
void main(){
	P1=0xff;P2=0x00;
	while(1){
		key=MatrixKey();												//	调用矩阵键盘扫描函数获取键值
		P1=smg[key];													//	将键值转换为对应的七段码并输出到P1口，显示在数码管上
	}
}