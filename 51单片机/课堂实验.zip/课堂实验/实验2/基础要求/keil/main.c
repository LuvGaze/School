#include <reg51.h>

sbit P3_0=P3^0;
sbit P3_1=P3^1;
sbit P3_2=P3^2;
sbit P3_3=P3^3;
sbit P3_4=P3^4;
sbit P3_5=P3^5;
unsigned char smg[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x80};

void Delay(){													// 延时函数
	unsigned char i;
	for(i=0;i<110;i++);
}
void Nixie(unsigned int Location,Number){
	switch(Location){											//	根据位置选择不同的位选组合
		case 1:P3_0=0;P3_1=1;P3_2=1;P3_3=1;P3_4=1;P3_5=1;break;	//	选中第1个数码管
		case 2:P3_0=1;P3_1=0;P3_2=1;P3_3=1;P3_4=1;P3_5=1;break;	//	选中第2个数码管
		case 3:P3_0=1;P3_1=1;P3_2=0;P3_3=1;P3_4=1;P3_5=1;break;	//	选中第3个数码管
		case 4:P3_0=1;P3_1=1;P3_2=1;P3_3=0;P3_4=1;P3_5=1;break;	//	选中第4个数码管
		case 5:P3_0=1;P3_1=1;P3_2=1;P3_3=1;P3_4=0;P3_5=1;break;	//	选中第5个数码管
		case 6:P3_0=1;P3_1=1;P3_2=1;P3_3=1;P3_4=1;P3_5=0;break;	//	选中第6个数码管
	}
	P2=smg[Number];												//	输出Number对应的七段码到P2口，显示数字
	Delay();													//	延时以确保显示稳定
	P3_0=1;P3_1=1;P3_2=1;P3_3=1;P3_4=1;P3_5=1;					//	消影
}
void main(){
	long int a=123456;											//	定义要显示的数字
	while(1){
		Nixie(1,a/100000);										//	显示十万位
		Nixie(2,a%100000/10000);								//	显示万位
		Nixie(3,a%10000/1000);									//	显示千位
		Nixie(4,a%1000/100);									//	显示百位
		Nixie(5,a%100/10);										//	显示十位
		Nixie(6,a%10);											//	显示个位
	}
}