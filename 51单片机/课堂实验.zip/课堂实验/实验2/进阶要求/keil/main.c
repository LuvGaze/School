#include <reg51.h>
#include <math.h>
sbit P3_0=P3^0;
sbit P3_1=P3^1;
sbit P3_2=P3^2;
sbit P3_3=P3^3;
sbit P3_4=P3^4;
sbit P3_5=P3^5;
float x=109.407;													//	自定义0.000-999.999小数
unsigned char smg[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x80};
void Delay(){
	unsigned char i;
		for(i=0;i<220;i++);
}
void Nixie(unsigned int Location,Number)
{
	switch(Location){
		case 1:P3_0=0;P3_1=1;P3_2=1;P3_3=1;P3_4=1;P3_5=1;break;	//	显示第1个数码管
		case 2:P3_0=1;P3_1=0;P3_2=1;P3_3=1;P3_4=1;P3_5=1;break;	//	显示第2个数码管
		case 3:P3_0=1;P3_1=1;P3_2=0;P3_3=1;P3_4=1;P3_5=1;break;	//	显示第3个数码管
		case 4:P3_0=1;P3_1=1;P3_2=1;P3_3=0;P3_4=1;P3_5=1;break;	//	显示第4个数码管
		case 5:P3_0=1;P3_1=1;P3_2=1;P3_3=1;P3_4=0;P3_5=1;break;	//	显示第5个数码管
		case 6:P3_0=1;P3_1=1;P3_2=1;P3_3=1;P3_4=1;P3_5=0;break;	//	显示第6个数码管
	}
	P2=smg[Number];												//	显示数码管
	Delay();
	P3_0=1;P3_1=1;P3_2=1;P3_3=1;P3_4=1;P3_5=1;					//	消影
}
void main(){
	while(1){
		Nixie(1,x/100);											//	显示百位
		Nixie(2,fmod(x,100)/10);								//	显示十位
		Nixie(3,fmod(x,10));									//	显示个位
		Nixie(4,fmod(x*10,10));									//	显示十分位
		Nixie(5,fmod(x*100,10));								//	显示百分位
		Nixie(6,fmod(x*1000,10));								//	显示千分位
		Nixie(3,10);											//	显示小数点
	}
}