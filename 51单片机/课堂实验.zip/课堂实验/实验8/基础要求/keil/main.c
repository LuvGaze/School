#include <reg51.h>

sbit SCK = P2^5;
sbit CS  = P2^6;
sbit DIN = P2^7;

void DAC(unsigned int adata)		//	用于将数字量转换为模拟电压输出
{
	unsigned int i;
	adata <<= 6;					//	将输入的数字量左移6位，D/A转换器为12位，此操作是为了与D/A的输入位对齐
	SCK	= 0;						//	片选有效，开始数据传输
	CS  = 0;
	for(i=0;i<12;i++){				//	12位数据传输，每次循环处理1位
		SCK = 0;					//	在时钟低电平时准备数据
		adata <<= 1;				//	数据左移一位，准备下一位的传输
		DIN = CY;
		SCK = 1;					//	时钟脉冲上升沿，数据被D/A转换器读取
	}
	CS  = 1;						//	数据传输结束，取消片选
	SCK = 0;						//	最后时钟设为低电平，为下一次传输做准备
}

void main(){
	unsigned int i;
	while(1){
		for(i=0;i<1000;i++){		//	上升
			DAC(i);					//	调用DAC函数输出相应电压
		}
		for(i=1000;i>0;i--){		//	下降
			DAC(i);					//	调用DAC函数输出相应电压
		}
	}
}