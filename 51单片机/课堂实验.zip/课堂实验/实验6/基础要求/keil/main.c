#include <reg51.h>

void Timer0_Init()					//	定时器初始化
{
	TMOD &= 0xF0;
	TMOD |= 0x02;
	TL0 = 0xA4;
	TH0 = 0xA4;
	TF0 = 0;
	TR0 = 1;
}

void main()
{
	unsigned int count = 0;
	Timer0_Init();					//	调用时器初始化
	P2=1;
	while(1)
	{	
		if(TF0==1)
		{
			TF0=0;
			count++;
			if(count>=10000)		//	判断定时大小
			{
				count = 0;
				P2=~P2;				//	LED状态反转
			}
		}
	}
}