#include <REGX52.H>
#include "Delay.h"
#include "LCD1602.h"
#include "MatrixKey.h"

unsigned char KeyNum;
unsigned int Password,Count,mm;

void main()
{
	LCD_Init();
	LCD_ShowString(1,1,"Password:");
	while(1)
	{
		KeyNum=MatrixKey();
		if(KeyNum)
		{
			if(KeyNum<=10)	
			{
				if(Count<4)	
				{
					Password*=10;				
					Password+=KeyNum%10;		
					Count++;	
				}
				LCD_ShowNum(2,1,Password,4);	
			}
			if(KeyNum==11)	
			{
				if(Password==mm)	
				{
					LCD_ShowString(1,14,"OK ");	
					Password=0;		
					Count=0;		
					break;
				}
				else			
				{
					LCD_ShowString(1,14,"ERR");	
					Password=0;
					Count=0;		
					LCD_ShowNum(2,1,0,4);
				}
			}
			if(KeyNum==12)
			{
				Password=0;
				Count=0;
			}
			
			if(KeyNum==13)	
			{
				Password=0;		
				Count=0;	
				break;
			}
		}
	}
}
