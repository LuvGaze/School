#include <REGX52.H>

void main()
{
	P2=0xFE;	//1111 1110
	while(1)
	{
		
	}
}