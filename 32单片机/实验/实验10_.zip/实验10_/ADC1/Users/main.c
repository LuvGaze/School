/**
 ******************************************************************************
 * @file     main.c
 * @author   ����ԭ���Ŷ�(ALIENTEK)
 * @version  V1.0
 * @date     2020-08-20
 * @brief    �½�����ʵ��-HAL��汾 ʵ��
 * @license  Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ******************************************************************************
 * @attention
 * 
 * ʵ��ƽ̨:����ԭ�� STM32F103 ������
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 ******************************************************************************
 */

#include "./SYSTEM/sys/sys.h"
#include "./BSP/UART/uart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/ADC/adc.h"
#include "./BSP/TIMER/timer.h"
#include "./BSP/LED/led.h"



extern UART_HandleTypeDef g_uart1_handle;
extern int p;
uint8_t f_adcx[] = "0.00\r\n";
void trans_f_to_chars(float x)
{
    uint16_t temp1;
    temp1 = x*100;
    f_adcx[0]=temp1/100+0x30;
    f_adcx[2]=temp1%100/10+0x30;
    f_adcx[3]=temp1%10+0x30;
}


int main(void)
{
    uint16_t adcx;
    float temp[6];
	float avg;
	int f=0;
    HAL_Init();                              /* ��ʼ��HAL�� */
    sys_stm32_clock_init(RCC_PLL_MUL9);      /* ����ʱ��, 72Mhz */
    delay_init(72);                          /* ��ʱ��ʼ�� */
    uart_init(115200);
    adc_init();
	led_init();                              /* LED��ʼ�� */
    timer_init(2500-1,7200-1);
    while(1)
	 {
		if(p==1){
			adcx =adc_get_result();
			temp[f] = (float)adcx*(3.3/4096);
			trans_f_to_chars(temp[f]);
			HAL_UART_Transmit(&g_uart1_handle, f_adcx, 6, 1000);
			f++;
			p=0;
		}
		
		if(f==5){
			avg=(temp[1]+temp[2]+temp[3]+temp[4]+temp[0])/5;
			trans_f_to_chars(avg);
			HAL_UART_Transmit(&g_uart1_handle, "avg:", 4, 1000);
			HAL_UART_Transmit(&g_uart1_handle, f_adcx, 6, 1000);
			HAL_UART_Transmit(&g_uart1_handle, "\n", 1, 1000);
			f=0;
		}
	}
}
