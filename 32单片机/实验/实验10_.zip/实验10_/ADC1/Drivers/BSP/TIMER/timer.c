#include "./BSP/TIMER/timer.h"

extern int p=0;
TIM_HandleTypeDef g_timer_handle;
void timer_init(uint16_t arr,uint16_t psc)
{
    g_timer_handle.Instance = TIM6;
    g_timer_handle.Init.Period = arr;
    g_timer_handle.Init.Prescaler = psc;
    HAL_TIM_Base_Init(&g_timer_handle);
    HAL_TIM_Base_Start_IT(&g_timer_handle);
}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM6)
    {
        __HAL_RCC_TIM6_CLK_ENABLE();
        HAL_NVIC_SetPriority(TIM6_IRQn, 3, 1);
        HAL_NVIC_EnableIRQ(TIM6_IRQn);
    }
}

void TIM6_IRQHandler(void)
{
    HAL_TIM_IRQHandler(&g_timer_handle);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM6)
    {
        HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_5);
		p=1;
    }
}
