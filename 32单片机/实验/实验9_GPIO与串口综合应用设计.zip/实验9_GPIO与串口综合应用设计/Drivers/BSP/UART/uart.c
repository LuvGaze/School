#include "./BSP/UART/uart.h"

UART_HandleTypeDef g_uart1_handle;

uint8_t g_rx_buffer[1];

void uart_init(uint32_t baud)
{
	g_uart1_handle.Instance = USART1;
	g_uart1_handle.Init.BaudRate = baud;
	g_uart1_handle.Init.WordLength = UART_WORDLENGTH_8B;
	g_uart1_handle.Init.StopBits = UART_STOPBITS_1;
	g_uart1_handle.Init.Parity = UART_PARITY_NONE;
	g_uart1_handle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	g_uart1_handle.Init.Mode = UART_MODE_TX_RX;
	
	HAL_UART_Init(&g_uart1_handle);
	
	HAL_UART_Receive_IT(&g_uart1_handle, g_rx_buffer, 1);
}
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
	GPIO_InitTypeDef gpio_init_struct;
	if(huart->Instance == USART1)
	{
		__HAL_RCC_USART1_CLK_ENABLE();
		__HAL_RCC_GPIOA_CLK_ENABLE();
		gpio_init_struct.Pin = GPIO_PIN_9;
		gpio_init_struct.Mode = GPIO_MODE_AF_PP;
		gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;
		HAL_GPIO_Init(GPIOA,&gpio_init_struct);
		
		gpio_init_struct.Pin = GPIO_PIN_10;
		gpio_init_struct.Mode = GPIO_MODE_AF_INPUT;
		gpio_init_struct.Pull = GPIO_PULLUP;
		HAL_GPIO_Init(GPIOA,&gpio_init_struct);
		
		HAL_NVIC_SetPriority(USART1_IRQn, 3, 3);
		HAL_NVIC_EnableIRQ(USART1_IRQn);
		
	}
}
void USART1_IRQHandler()
{
	HAL_UART_IRQHandler(&g_uart1_handle);
	
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == USART1)
	{
        switch(g_rx_buffer[0])
        {
            case '1':HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_5);
				break;
            case '2':HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_5);
				break;
            case '3':HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_RESET);
					 HAL_GPIO_WritePin(GPIOE,GPIO_PIN_5,GPIO_PIN_RESET);
				break;
        }
        
		HAL_UART_Transmit(&g_uart1_handle, g_rx_buffer, 1, 1000);
		HAL_UART_Receive_IT(&g_uart1_handle, g_rx_buffer, 1);
	}
}

void led1_init(void)
{
    GPIO_InitTypeDef gpio_init_struct;
    __HAL_RCC_GPIOB_CLK_ENABLE();
    gpio_init_struct.Pin=GPIO_PIN_5;
    gpio_init_struct.Mode=GPIO_MODE_OUTPUT_PP;
    gpio_init_struct.Speed=GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB,&gpio_init_struct);
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_SET);

}
void led2_init(void)
{
    GPIO_InitTypeDef gpio_init_struct;
    __HAL_RCC_GPIOE_CLK_ENABLE();
    gpio_init_struct.Pin=GPIO_PIN_5;
    gpio_init_struct.Mode=GPIO_MODE_OUTPUT_PP;
    gpio_init_struct.Speed=GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOE,&gpio_init_struct);
    HAL_GPIO_WritePin(GPIOE,GPIO_PIN_5,GPIO_PIN_SET);

}
