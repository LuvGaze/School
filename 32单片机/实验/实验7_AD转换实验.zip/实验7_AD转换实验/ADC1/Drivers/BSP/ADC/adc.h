#ifndef __ADC_H
#define __ADC_H

#include "./SYSTEM/sys/sys.h"

void adc_init(void);
uint16_t adc_get_result(void);


#endif
