#ifndef __UART_H
#define __UART_H

#include "./SYSTEM/sys/sys.h"

void uart_init(uint32_t baud);


#endif
