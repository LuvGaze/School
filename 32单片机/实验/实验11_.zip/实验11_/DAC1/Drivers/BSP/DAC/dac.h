#ifndef __DAC_H
#define __DAC_H

#include "./SYSTEM/sys/sys.h"

void dac_init(void);
void dac_setv(float vol);

#endif
