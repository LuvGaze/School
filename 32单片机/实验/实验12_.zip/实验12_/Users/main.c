/**
 ******************************************************************************
 * @file     main.c
 * @author   ����ԭ���Ŷ�(ALIENTEK)
 * @version  V1.0
 * @date     2020-08-20
 * @brief    �½�����ʵ��-HAL��汾 ʵ��
 * @license  Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ******************************************************************************
 * @attention
 * 
 * ʵ��ƽ̨:����ԭ�� STM32F103 ������
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 ******************************************************************************
 */

#include "./SYSTEM/sys/sys.h"
#include "./BSP/UART/uart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/ADC/adc.h"
#include "./BSP/DAC/dac.h"
#include "./BSP/TIMER/timer.h"
#include "./BSP/EXTI/exti.h"
#include "./BSP/LED/led.h"

extern UART_HandleTypeDef g_uart1_handle;
extern uint8_t g_rx_buffer[1];
extern uint8_t KeyNum;
extern float value;
int P_LED = 1;
int flag_Toggle = 0;
extern int P;
float temp;
uint8_t f_adcx[] = "0.00V\r\n";
uint16_t adcx;
uint16_t k = 0;
uint16_t Count_200ms = 0;


void LED_change()
{
    if(value>=0.5&&value<=3.0)
    {
    HAL_GPIO_WritePin(GPIOE,GPIO_PIN_5,GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_RESET);
    }
    else
    {
//        P_LED = -P_LED;
        HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_SET);
		flag_Toggle++;
        if(flag_Toggle == 5)
        {
			flag_Toggle = 0;
            HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_5);
        }   
        
    }
}

void trans_f_to_chars(float x)
{
    uint16_t temp1;
    temp1 = x*100+1;
    f_adcx[0]=temp1/100+0x30;
    f_adcx[2]=temp1%100/10+0x30;
    f_adcx[3]=temp1%10+0x30;
}


int main(void)
{
    HAL_Init();                              /* ��ʼ��HAL�� */
    sys_stm32_clock_init(RCC_PLL_MUL9);      /* ����ʱ��, 72Mhz */
    delay_init(72);                          /* ��ʱ��ʼ�� */
    uart_init(115200);
    adc_init();
    dac_init();
    exti_init();
    led_init();
    timer_init(2000-1,7200-1);
    while(1)
    {
        if(P == 1)						//	ÿ�����5��
        {
			timer_init(2000-1,7200-1);
            P = 0;

            if(KeyNum == 1)
			{
				value = 1.5;
				KeyNum = 0;
			}
            
            LED_change();				//	�ж�LED״̬
			
            dac_setv(value);
            adcx =adc_get_result();
            temp = (float)adcx*(3.3/4096);
            trans_f_to_chars(temp);
            HAL_UART_Transmit(&g_uart1_handle, f_adcx, 7, 1000);  
            HAL_UART_Transmit(&g_uart1_handle, "\n", 1, 1000); 

        }     
    }
}




