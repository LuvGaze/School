#include "./BSP/DAC/dac.h"
DAC_HandleTypeDef g_dac_handle;
void dac_init(void)
{
    DAC_ChannelConfTypeDef dac_ch_conf;
    g_dac_handle.Instance = DAC;
    HAL_DAC_Init(&g_dac_handle);
    dac_ch_conf.DAC_Trigger = DAC_TRIGGER_NONE;
    dac_ch_conf.DAC_OutputBuffer = DAC_OUTPUTBUFFER_DISABLE;
    HAL_DAC_ConfigChannel(&g_dac_handle, &dac_ch_conf, DAC_CHANNEL_1);
    HAL_DAC_Start(&g_dac_handle,DAC_CHANNEL_1);
}

void HAL_DAC_MspInit(DAC_HandleTypeDef *hdac)
{
    GPIO_InitTypeDef gpio_init_struct;
    if(hdac->Instance == DAC)
    {
        __HAL_RCC_GPIOA_CLK_ENABLE();
        __HAL_RCC_DAC_CLK_ENABLE();
        gpio_init_struct.Pin = GPIO_PIN_4;
        gpio_init_struct.Mode = GPIO_MODE_ANALOG;
        HAL_GPIO_Init(GPIOA, &gpio_init_struct);
    }
}

void dac_setv(float vol)
{
    float temp;
    temp = vol/3.3*4096;
    if(temp >4095)
        temp =4095;
    HAL_DAC_SetValue(&g_dac_handle,DAC_CHANNEL_1, DAC_ALIGN_12B_R, temp);
}
