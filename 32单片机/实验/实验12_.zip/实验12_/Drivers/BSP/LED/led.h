#ifndef __LED_H
#define __LED_H

#include "./SYSTEM/sys/sys.h"

void led_init(void);


#endif
