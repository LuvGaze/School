#ifndef __KEY_H
#define __KEY_H

#include "./SYSTEM/sys/sys.h"

void key_init(void);
uint8_t key1_scan(void);
uint8_t key2_scan(void);

#endif
